"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 2841:
/*!****************************!*\
  !*** ./src/app/AppData.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppData": () => (/* binding */ AppData)
/* harmony export */ });
class AppData {
    constructor(data) {
        this.data = data;
    }
}


/***/ }),

/***/ 2003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 2003);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 2267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var C_Users_ME_Documents_LocalDev_UTH_ionicIot_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _services_s_arduino_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/s-arduino.service */ 4651);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _AppData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../AppData */ 2841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 3491);









const source$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.interval)(3000);
let HomePage = class HomePage {
  constructor(serviceArduino, alertController) {
    this.serviceArduino = serviceArduino;
    this.alertController = alertController;
    this.server = '192.168.1.17';
    this.debugFlag = false;
  }

  ngOnInit() {
    this.status = null;
    this.tipoRiego = 'terrestre';
    this.presentAlert();
    this.timeStart = '';
    this.timeEnd = '';
    this.temperaturaStart = 0;
    this.temperaturaEnd = 0;
  }

  ngAfterViewInit() {
    this.toogleButton = document.getElementById("tooglePump");
    console.log(this.toogleButton);
  }

  debugStatus(opt) {
    this.requestData('0');
  }

  offTipoRiego() {
    this.status.data.aereo = 0;
    this.status.data.terrestre = 0;
  }

  checkTipoRiego() {
    console.log(this.tipoRiego);
    this.offTipoRiego();

    if (this.tipoRiego == 'terrestre') {
      console.log('Ejecuta terrestre');
      this.status.data.terrestre = 1;
    }

    if (this.tipoRiego == 'aereo') {
      this.status.data.aereo = 1;
      console.log('Ejecuta aereo');
    }

    if (this.tipoRiego == 'ambos') {
      console.log('Ejecuta Ambos');
      this.status.data.aereo = 1;
      this.status.data.terrestre = 1;
    }
  }

  powerOffSystem() {
    this.status.data.pump = 0;
    this.status.data.fan1 = 0;
    this.status.data.fan2 = 0;
    this.status.data.aereo = 0;
    this.status.data.terrestre = 0;
  }

  startFans() {
    this.status.data.fan1 = 1;
    this.status.data.fan2 = 1;
  }

  stopFans() {
    this.status.data.fan1 = 0;
    this.status.data.fan2 = 0;
  }

  enableAutomatic() {
    this.automatic = true;
  }

  disableAutomatic() {
    this.automatic = false;
  }

  requestData(opt) {
    this.serviceArduino.getStatus(this.server, '0').subscribe(data => {
      if (this.status.data.pump != data.pump || this.status.data.fan1 != data.fan1 || this.status.data.fan2 != data.fan2 || this.status.data.aereo != data.aereo || this.status.data.terrestre != data.terrestre || this.status.data.temperatura != data.temperatura || this.status.data.caudal != data.caudal || this.status.data.volume != data.volume || this.status.data.humedad1 != data.humedad1 || this.status.data.humedad1 != data.humedad2) {
        console.log('cambio detectado');
        this.serviceArduino.getStatus(this.server, opt).toPromise();
        console.log('cambio ejecutado');
        console.log('----------------');
      }
    });
  }

  presentAlert() {
    var _this = this;

    return (0,C_Users_ME_Documents_LocalDev_UTH_ionicIot_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this.alertController.create({
        header: 'Configuración del Servidor',
        buttons: [{
          text: 'Cancel'
        }, {
          text: 'OK',
          handler: data => {
            if (data[0] != '') {
              _this.server = data[0];
            }

            _this.serviceArduino.getStatus(_this.server, '0').subscribe(_data => {
              _this.status = new _AppData__WEBPACK_IMPORTED_MODULE_4__.AppData(_data);
              source$.subscribe(x => {
                //Server
                if (_this.server != '') {
                  _this.serviceArduino.getStatus(_this.server, '0').subscribe(__data => {
                    //Humedad
                    if ((__data.humedad1 <= _this.humedadMinima || __data.humedad2 <= _this.humedadMinima) && _this.automatic) {
                      _this.status.data.pump = 1;
                      _this.checkTipoRiego;
                      console.log('Encendido automático por umbral de humedad');
                    }

                    if ((__data.humedad1 >= _this.humedadMaxima || __data.humedad2 >= _this.humedadMaxima) && _this.automatic) {
                      _this.status.data.pump = 0;
                      _this.status.data.aereo = 0;
                      _this.status.data.terrestre = 0;
                      console.log('Apagado automático por umbral de humedad');
                    } //Tiempo


                    if (_this.timeStart != '') {
                      _this.now = new Date();
                      _this.nowHour = _this.now.getHours();
                      _this.nowMins = _this.now.getMinutes();

                      if (_this.nowHour == Number(_this.timeStart.substring(0, _this.timeStart.indexOf(':'))) && _this.nowMins == Number(_this.timeStart.substring(_this.timeStart.indexOf(':') + 1, _this.timeStart.length))) {
                        _this.status.data.pump = 1;

                        _this.checkTipoRiego();

                        console.log('Encendido automatico por umbral de tiempo');
                      }
                    }

                    if (_this.timeEnd != '') {
                      _this.now = new Date();
                      _this.nowHour = _this.now.getHours();
                      _this.nowMins = _this.now.getMinutes();

                      if (_this.nowHour == Number(_this.timeEnd.substring(0, _this.timeEnd.indexOf(':'))) && _this.nowMins == Number(_this.timeEnd.substring(_this.timeEnd.indexOf(':') + 1, _this.timeEnd.length))) {
                        _this.status.data.pump = 0;

                        _this.offTipoRiego();

                        console.log('Apagado automatico por umbral de tiempo');
                      }
                    } //Temperatura


                    console.log(_this.temperaturaStart, __data.temperatura, _this.temperaturaEnd);

                    if (__data.temperatura >= _this.temperaturaStart && __data.temperatura <= _this.temperaturaEnd && _this.automatic) {
                      _this.startFans();

                      console.log('Start Fans');
                    } else if (_this.automatic) {
                      _this.stopFans();
                    }

                    if (__data.pump == 1) {
                      _this._statusSystem = true;

                      _this.checkTipoRiego();
                    } else {
                      _this._statusSystem = false;
                    }

                    if (_this.status.data.pump != __data.pump || _this.status.data.fan1 != __data.fan1 || _this.status.data.fan2 != __data.fan2 || _this.status.data.humedad1 != __data.humedad1 || _this.status.data.humedad2 != __data.humedad2 || _this.status.data.aereo != __data.aereo || _this.status.data.terrestre != __data.terrestre || _this.status.data.temperatura != __data.temperatura || _this.status.data.caudal != __data.caudal || _this.status.data.volume != __data.volume) {
                      console.log('cambio detectado server-side');
                      /*this.updateStatusSensors();*/

                      console.log(__data);
                      setTimeout(function (scope) {
                        return function () {
                          scope.serviceArduino.getStatus(scope.server, '0').subscribe(__data => {
                            if (scope.status.data.pump != __data.pump || scope.status.data.fan1 != __data.fan1 || scope.status.data.fan2 != __data.fan2 || scope.status.data.humedad1 != __data.humedad1 || scope.status.data.humedad2 != __data.humedad2 || scope.status.data.aereo != __data.aereo || scope.status.data.terrestre != __data.terrestre || scope.status.data.temperatura != __data.temperatura || scope.status.data.caudal != __data.caudal || scope.status.data.volume != __data.volume) {
                              scope.status.data = __data; // scope.updateStatusSensors();  
                              // console.log(scope.status.data); 
                              // console.log('cambio ejecutado server-side');
                            }
                          });
                          console.log('----------------');
                        };
                      }(_this), 1000);
                    }
                  });
                }
              });
            });
          }
        }],
        inputs: [{
          placeholder: _this.server
        }]
      });
      yield alert.present();
    })();
  }

  presentAlertTipoRiego() {
    var _this2 = this;

    return (0,C_Users_ME_Documents_LocalDev_UTH_ionicIot_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this2.alertController.create({
        header: 'Seleccione Tipo Riego',
        buttons: [{
          text: 'OK',
          handler: data => {
            console.log("Riego:" + data);
            _this2.tipoRiego = data;

            _this2.checkTipoRiego();
          }
        }],
        inputs: [{
          label: 'Riego Aereo',
          type: 'radio',
          value: 'aereo'
        }, {
          label: 'Riego Subterráneo',
          type: 'radio',
          value: 'terrestre'
        }, {
          label: 'Ambos',
          type: 'radio',
          value: 'ambos'
        }]
      });
      yield alert.present();
    })();
  }

  presentAlertTemperature() {
    var _this3 = this;

    return (0,C_Users_ME_Documents_LocalDev_UTH_ionicIot_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this3.alertController.create({
        header: 'Seleccione Temperatura Limite',
        buttons: [{
          text: 'OK',
          handler: data => {
            console.log("Temperatura:", data[0], data[1]);

            if (data[0] != '' && data[1] != '') {
              _this3.temperaturaStart = Number(data[0]);
              _this3.temperaturaEnd = Number(data[1]);
            }
          }
        }],
        inputs: [{
          placeholder: 'Minima',
          type: 'number'
        }, {
          placeholder: 'Máxima',
          type: 'number'
        }]
      });
      yield alert.present();
    })();
  }

  presentAlertHumidity() {
    var _this4 = this;

    return (0,C_Users_ME_Documents_LocalDev_UTH_ionicIot_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this4.alertController.create({
        header: 'Humedad minima y máxima',
        buttons: [{
          text: 'OK',
          handler: data => {
            _this4.humedadMinima = data[0];
            _this4.humedadMaxima = data[1];
            console.log("Humedad Min/Max:", _this4.humedadMinima, _this4.humedadMaxima);
          }
        }],
        inputs: [{
          placeholder: 'Minima',
          type: 'number'
        }, {
          placeholder: 'Máxima',
          type: 'number'
        }]
      });
      yield alert.present();
    })();
  }

  presentAlertTime() {
    var _this5 = this;

    return (0,C_Users_ME_Documents_LocalDev_UTH_ionicIot_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this5.alertController.create({
        header: 'Please enter your info',
        buttons: [{
          text: 'OK',
          handler: data => {
            _this5.timeStart = String(data[0]);
            _this5.timeEnd = String(data[1]);
          }
        }],
        inputs: [{
          type: 'time'
        }, {
          type: 'time'
        }]
      });
      yield alert.present();
    })();
  }

};

HomePage.ctorParameters = () => [{
  type: _services_s_arduino_service__WEBPACK_IMPORTED_MODULE_3__.SArduinoService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController
}];

HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-home',
  template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], HomePage);


/***/ }),

/***/ 4651:
/*!***********************************************!*\
  !*** ./src/app/services/s-arduino.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SArduinoService": () => (/* binding */ SArduinoService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 8987);



let SArduinoService = class SArduinoService {
    constructor(http) {
        this.http = http;
    }
    getStatus(server, opt = "") {
        let url = "http://" + server + '/action?opt=' + opt;
        return this.http.get(url);
    }
};
SArduinoService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient }
];
SArduinoService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], SArduinoService);



/***/ }),

/***/ 1925:
/*!**********************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/Scheduler.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Scheduler": () => (/* binding */ Scheduler)
/* harmony export */ });
class Scheduler {
  constructor(SchedulerAction, now = Scheduler.now) {
    this.SchedulerAction = SchedulerAction;
    this.now = now;
  }

  schedule(work, delay = 0, state) {
    return new this.SchedulerAction(this, work).schedule(state, delay);
  }

}

Scheduler.now = () => Date.now();

/***/ }),

/***/ 3491:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/interval.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "interval": () => (/* binding */ interval)
/* harmony export */ });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Observable */ 2378);
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../scheduler/async */ 328);
/* harmony import */ var _util_isNumeric__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/isNumeric */ 7269);



function interval(period = 0, scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.async) {
  if (!(0,_util_isNumeric__WEBPACK_IMPORTED_MODULE_1__.isNumeric)(period) || period < 0) {
    period = 0;
  }

  if (!scheduler || typeof scheduler.schedule !== 'function') {
    scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.async;
  }

  return new _Observable__WEBPACK_IMPORTED_MODULE_2__.Observable(subscriber => {
    subscriber.add(scheduler.schedule(dispatch, period, {
      subscriber,
      counter: 0,
      period
    }));
    return subscriber;
  });
}

function dispatch(state) {
  const {
    subscriber,
    counter,
    period
  } = state;
  subscriber.next(counter);
  this.schedule({
    subscriber,
    counter: counter + 1,
    period
  }, period);
}

/***/ }),

/***/ 5353:
/*!*****************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/scheduler/Action.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Action": () => (/* binding */ Action)
/* harmony export */ });
/* harmony import */ var _Subscription__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Subscription */ 2425);

class Action extends _Subscription__WEBPACK_IMPORTED_MODULE_0__.Subscription {
  constructor(scheduler, work) {
    super();
  }

  schedule(state, delay = 0) {
    return this;
  }

}

/***/ }),

/***/ 3670:
/*!**********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/scheduler/AsyncAction.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AsyncAction": () => (/* binding */ AsyncAction)
/* harmony export */ });
/* harmony import */ var _Action__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Action */ 5353);

class AsyncAction extends _Action__WEBPACK_IMPORTED_MODULE_0__.Action {
  constructor(scheduler, work) {
    super(scheduler, work);
    this.scheduler = scheduler;
    this.work = work;
    this.pending = false;
  }

  schedule(state, delay = 0) {
    if (this.closed) {
      return this;
    }

    this.state = state;
    const id = this.id;
    const scheduler = this.scheduler;

    if (id != null) {
      this.id = this.recycleAsyncId(scheduler, id, delay);
    }

    this.pending = true;
    this.delay = delay;
    this.id = this.id || this.requestAsyncId(scheduler, this.id, delay);
    return this;
  }

  requestAsyncId(scheduler, id, delay = 0) {
    return setInterval(scheduler.flush.bind(scheduler, this), delay);
  }

  recycleAsyncId(scheduler, id, delay = 0) {
    if (delay !== null && this.delay === delay && this.pending === false) {
      return id;
    }

    clearInterval(id);
    return undefined;
  }

  execute(state, delay) {
    if (this.closed) {
      return new Error('executing a cancelled action');
    }

    this.pending = false;

    const error = this._execute(state, delay);

    if (error) {
      return error;
    } else if (this.pending === false && this.id != null) {
      this.id = this.recycleAsyncId(this.scheduler, this.id, null);
    }
  }

  _execute(state, delay) {
    let errored = false;
    let errorValue = undefined;

    try {
      this.work(state);
    } catch (e) {
      errored = true;
      errorValue = !!e && e || new Error(e);
    }

    if (errored) {
      this.unsubscribe();
      return errorValue;
    }
  }

  _unsubscribe() {
    const id = this.id;
    const scheduler = this.scheduler;
    const actions = scheduler.actions;
    const index = actions.indexOf(this);
    this.work = null;
    this.state = null;
    this.pending = false;
    this.scheduler = null;

    if (index !== -1) {
      actions.splice(index, 1);
    }

    if (id != null) {
      this.id = this.recycleAsyncId(scheduler, id, null);
    }

    this.delay = null;
  }

}

/***/ }),

/***/ 2901:
/*!*************************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/scheduler/AsyncScheduler.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AsyncScheduler": () => (/* binding */ AsyncScheduler)
/* harmony export */ });
/* harmony import */ var _Scheduler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Scheduler */ 1925);

class AsyncScheduler extends _Scheduler__WEBPACK_IMPORTED_MODULE_0__.Scheduler {
  constructor(SchedulerAction, now = _Scheduler__WEBPACK_IMPORTED_MODULE_0__.Scheduler.now) {
    super(SchedulerAction, () => {
      if (AsyncScheduler.delegate && AsyncScheduler.delegate !== this) {
        return AsyncScheduler.delegate.now();
      } else {
        return now();
      }
    });
    this.actions = [];
    this.active = false;
    this.scheduled = undefined;
  }

  schedule(work, delay = 0, state) {
    if (AsyncScheduler.delegate && AsyncScheduler.delegate !== this) {
      return AsyncScheduler.delegate.schedule(work, delay, state);
    } else {
      return super.schedule(work, delay, state);
    }
  }

  flush(action) {
    const {
      actions
    } = this;

    if (this.active) {
      actions.push(action);
      return;
    }

    let error;
    this.active = true;

    do {
      if (error = action.execute(action.state, action.delay)) {
        break;
      }
    } while (action = actions.shift());

    this.active = false;

    if (error) {
      while (action = actions.shift()) {
        action.unsubscribe();
      }

      throw error;
    }
  }

}

/***/ }),

/***/ 328:
/*!****************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/scheduler/async.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "async": () => (/* binding */ async),
/* harmony export */   "asyncScheduler": () => (/* binding */ asyncScheduler)
/* harmony export */ });
/* harmony import */ var _AsyncAction__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./AsyncAction */ 3670);
/* harmony import */ var _AsyncScheduler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AsyncScheduler */ 2901);


const asyncScheduler = new _AsyncScheduler__WEBPACK_IMPORTED_MODULE_0__.AsyncScheduler(_AsyncAction__WEBPACK_IMPORTED_MODULE_1__.AsyncAction);
const async = asyncScheduler;

/***/ }),

/***/ 7269:
/*!***************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/util/isNumeric.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isNumeric": () => (/* binding */ isNumeric)
/* harmony export */ });
/* harmony import */ var _isArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./isArray */ 4327);

function isNumeric(val) {
  return !(0,_isArray__WEBPACK_IMPORTED_MODULE_0__.isArray)(val) && val - parseFloat(val) + 1 >= 0;
}

/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".custom-content {\n  margin-top: 7vh;\n  margin-left: 5vw;\n  margin-right: 0vw;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\n\n.item-sensor {\n  margin-top: 2vh;\n}\n\n.toggleFan {\n  --handle-background-checked: #fff url(/assets/img/fan.png) no-repeat center / contain;\n}\n\n.toggleFan2 {\n  --handle-background-checked: #fff url(/assets/img/fan.png) no-repeat center / contain;\n}\n\n#tooglePump {\n  --handle-background-checked: rgba(246, 254, 16, 0.936) url(/assets/icon/bulb-outline.svg) no-repeat center / contain;\n}\n\nlabel {\n  position: relative;\n  width: 50vw;\n  height: 55px;\n  background: #212121;\n  border-radius: 50px;\n}\n\nlabel input {\n  -webkit-appearance: none;\n          appearance: none;\n}\n\nlabel span {\n  position: absolute;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  top: 0;\n  left: 0;\n  width: 50px;\n  height: 50px;\n  border: 4px solid #212121;\n  border-radius: 50%;\n  background: #333;\n  transition: 0.5s;\n}\n\nlabel input:checked ~ span {\n  left: 7vw;\n}\n\nlabel span ion-icon {\n  color: rgba(255, 255, 255, 0.25);\n  font-size: 2em;\n  transition: 0.5s;\n}\n\nlabel input:checked ~ span ion-icon {\n  color: rgb(255, 255, 255);\n  filter: drop-shadow(0 0 3px #fff) drop-shadow(0 0 7px #fff) drop-shadow(0 0 10px #fff);\n}\n\n.statusSystem {\n  margin-left: 2vw;\n  display: flex;\n}\n\n.sub-container {\n  display: flex;\n  flex-flow: row;\n  justify-content: space-around;\n  flex-wrap: wrap;\n}\n\n.card-sensors {\n  margin-top: 13vh;\n  max-width: 300vw;\n  min-width: 25vw;\n}\n\n.sensores-humedad {\n  margin-top: 2%;\n  margin-left: 15%;\n  margin-right: 15%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFFQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQUFGOztBQUdBO0VBQ0UsZUFBQTtBQUFGOztBQUdBO0VBQ0UscUZBQUE7QUFBRjs7QUFHQTtFQUNFLHFGQUFBO0FBQUY7O0FBR0E7RUFDRSxvSEFBQTtBQUFGOztBQUlBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFERjs7QUFHQTtFQUNFLHdCQUFBO1VBQUEsZ0JBQUE7QUFBRjs7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFBRjs7QUFJQTtFQUNFLFNBQUE7QUFERjs7QUFJQTtFQUNFLGdDQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBREY7O0FBSUE7RUFDRSx5QkFBQTtFQUNBLHNGQUFBO0FBREY7O0FBS0E7RUFDRSxnQkFBQTtFQUNBLGFBQUE7QUFGRjs7QUFPQTtFQUNFLGFBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7RUFDQSxlQUFBO0FBSkY7O0FBT0E7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUpGOztBQVFBO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFMRiIsImZpbGUiOiJob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jdXN0b20tY29udGVudHtcclxuICBtYXJnaW4tdG9wOiA3dmg7XHJcbiAgbWFyZ2luLWxlZnQ6IDV2dztcclxuICBtYXJnaW4tcmlnaHQ6IDB2dztcclxuXHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG4uaXRlbS1zZW5zb3J7XHJcbiAgbWFyZ2luLXRvcDogMnZoO1xyXG59XHJcblxyXG4udG9nZ2xlRmFuIHtcclxuICAtLWhhbmRsZS1iYWNrZ3JvdW5kLWNoZWNrZWQ6ICNmZmYgdXJsKC9hc3NldHMvaW1nL2Zhbi5wbmcpIG5vLXJlcGVhdCBjZW50ZXIgLyBjb250YWluO1xyXG59XHJcblxyXG4udG9nZ2xlRmFuMiB7XHJcbiAgLS1oYW5kbGUtYmFja2dyb3VuZC1jaGVja2VkOiAjZmZmIHVybCgvYXNzZXRzL2ltZy9mYW4ucG5nKSBuby1yZXBlYXQgY2VudGVyIC8gY29udGFpbjtcclxufVxyXG5cclxuI3Rvb2dsZVB1bXAge1xyXG4gIC0taGFuZGxlLWJhY2tncm91bmQtY2hlY2tlZDogcmdiYSgyNDYsIDI1NCwgMTYsIDAuOTM2KSB1cmwoL2Fzc2V0cy9pY29uL2J1bGItb3V0bGluZS5zdmcpIG5vLXJlcGVhdCBjZW50ZXIgLyBjb250YWluO1xyXG59XHJcblxyXG5cclxubGFiZWwge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogNTB2dztcclxuICBoZWlnaHQ6IDU1cHg7XHJcbiAgYmFja2dyb3VuZDogIzIxMjEyMTtcclxuICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG59XHJcbmxhYmVsIGlucHV0IHtcclxuICBhcHBlYXJhbmNlOiBub25lO1xyXG59XHJcblxyXG5sYWJlbCBzcGFuIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHdpZHRoOiA1MHB4O1xyXG4gIGhlaWdodDogNTBweDtcclxuICBib3JkZXI6IDRweCBzb2xpZCAjMjEyMTIxO1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gIHRyYW5zaXRpb246IDAuNXM7XHJcblxyXG59XHJcblxyXG5sYWJlbCBpbnB1dDpjaGVja2VkIH4gc3BhbiB7XHJcbiAgbGVmdDogN3Z3O1xyXG59XHJcblxyXG5sYWJlbCBzcGFuIGlvbi1pY29uIHtcclxuICBjb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjI1KTtcclxuICBmb250LXNpemU6IDJlbTtcclxuICB0cmFuc2l0aW9uOiAwLjVzO1xyXG59XHJcblxyXG5sYWJlbCBpbnB1dDpjaGVja2VkIH4gc3BhbiBpb24taWNvbiB7XHJcbiAgY29sb3I6IHJnYmEoMjU1LCAyNTUsIDI1NSwgMSk7XHJcbiAgZmlsdGVyOiBkcm9wLXNoYWRvdygwIDAgM3B4ICNmZmYpIGRyb3Atc2hhZG93KDAgMCA3cHggI2ZmZilcclxuICBkcm9wLXNoYWRvdygwIDAgMTBweCAjZmZmKTtcclxufVxyXG5cclxuLnN0YXR1c1N5c3RlbXtcclxuICBtYXJnaW4tbGVmdDogMnZ3O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgXHJcbn1cclxuXHJcblxyXG4uc3ViLWNvbnRhaW5lcntcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZmxvdzogcm93O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gIGZsZXgtd3JhcDogd3JhcDtcclxufVxyXG5cclxuLmNhcmQtc2Vuc29yc3tcclxuICBtYXJnaW4tdG9wOiAxM3ZoO1xyXG4gIG1heC13aWR0aDogMzAwdnc7XHJcbiAgbWluLXdpZHRoOiAyNXZ3O1xyXG5cclxufVxyXG5cclxuLnNlbnNvcmVzLWh1bWVkYWR7XHJcbiAgbWFyZ2luLXRvcDogMiU7XHJcbiAgbWFyZ2luLWxlZnQ6IDE1JTtcclxuICBtYXJnaW4tcmlnaHQ6IDE1JTtcclxufSJdfQ== */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title> Sistema de Riego</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content scroll-y=\"true\"  >\r\n\r\n\r\n  <ion-refresher slot=\"fixed\">\r\n    <ion-refresher-content>\r\n      \r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n  \r\n  <ion-item-divider *ngIf=\"this.status!=null\">\r\n    <ion-label>\r\n      <ion-text color=\"medium\"> Estado del Sistema</ion-text>\r\n    </ion-label>\r\n  </ion-item-divider>\r\n  <div class=\"statusSystem\" *ngIf=\"this.status!=null\">\r\n    <ion-progress-bar *ngIf=\"!!this.status.data.humedad1\" type=\"indeterminate\"></ion-progress-bar>\r\n    <ion-progress-bar *ngIf=\"!this.status.data.humedad2\"></ion-progress-bar>\r\n    <label>\r\n      <input [disabled]=\"true\" [checked]=\"this._statusSystem\" type=\"checkbox\">\r\n      <span>\r\n        <ion-icon name=\"bulb-outline\"></ion-icon>\r\n      </span>\r\n    </label>\r\n    \r\n    <ion-progress-bar *ngIf=\"!!this.status.data.humedad1\" type=\"indeterminate\" reversed=\"true\"></ion-progress-bar>\r\n    <ion-progress-bar *ngIf=\"!this.status.data.humedad2\"></ion-progress-bar>\r\n\r\n  </div>\r\n  \r\n<div class=\"sub-container\"> \r\n  <div class=\"custom-content\" *ngIf=\"this.status!=null\">\r\n        \r\n    <ion-item-divider>\r\n      <ion-label>\r\n        <ion-text color=\"medium\"> Panel de Control</ion-text>\r\n      </ion-label>\r\n    </ion-item-divider>\r\n    <ion-item>\r\n      <ion-toggle  [(ngModel)]=\"this.status.data.pump\" id=\"tooglePump\"  (ngModelChange)=\"requestData('1')\" >\r\n        <span>\r\n          <ion-icon name=\"bulb-outline\"></ion-icon>\r\n        </span>\r\n      </ion-toggle>\r\n      <ion-thumbnail slot=\"start\">\r\n        <img src=\"../assets/img/pump.png\">\r\n      </ion-thumbnail>\r\n      <ion-label>Bomba de Agua</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-toggle class=\"toggleFan\" [(ngModel)]=\"this.status.data.fan1\" (ngModelChange)=\"requestData('2')\" ></ion-toggle>\r\n      <ion-thumbnail slot=\"start\">\r\n        <img src=\"../assets/img/fan.png\">\r\n      </ion-thumbnail>\r\n      <ion-label>Ventiladora #1</ion-label>\r\n    </ion-item>\r\n\r\n\r\n    <ion-item>\r\n      <ion-toggle class=\"toggleFan\"  [(ngModel)]=\"this.status.data.fan2\" (ngModelChange)=\"requestData('3')\" ></ion-toggle>\r\n      <ion-thumbnail slot=\"start\">\r\n        <img src=\"../assets/img/fan.png\">\r\n      </ion-thumbnail>\r\n      <ion-label>Ventiladora #2</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-toggle [(ngModel)]=\"this.status.data.aereo\" (ngModelChange)=\"requestData('6')\" ></ion-toggle>\r\n      <ion-thumbnail slot=\"start\">\r\n        <img src=\"../assets/img/riegoAereo.png\">\r\n      </ion-thumbnail>\r\n      <ion-label>Riego Aéreo</ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-toggle  [(ngModel)]=\"this.status.data.terrestre\" (ngModelChange)=\"requestData('5')\" ></ion-toggle>\r\n      <ion-thumbnail slot=\"start\">\r\n        <img src=\"../assets/img/riegoTerrestre.png\">\r\n      </ion-thumbnail>\r\n      <ion-label>Riego Subterráneo</ion-label>\r\n    </ion-item>\r\n  </div>\r\n\r\n\r\n  <div class=\"card-sensors\" *ngIf=\"this.status!=null\">\r\n    <ion-card>\r\n      <ion-item>\r\n        <ion-thumbnail slot=\"start\">\r\n          <img src=\"../assets/img/temperatura.png\">\r\n        </ion-thumbnail>\r\n        <ion-label>Temperatura : {{this.status.data.temperatura}}°C </ion-label>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-thumbnail slot=\"start\">\r\n          <img src=\"../assets/img/caudal.png\">\r\n        </ion-thumbnail>\r\n        <ion-label>Caudal : {{this.status.data.caudal}} L/m </ion-label>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-thumbnail slot=\"start\">\r\n          <img src=\"../assets/img/litro.png\">\r\n        </ion-thumbnail>\r\n        <ion-label>Volumen : {{this.status.data.volume}} L </ion-label>\r\n      </ion-item>\r\n    </ion-card>\r\n  </div>\r\n\r\n</div>\r\n\r\n<div class=\"sensores-humedad\" *ngIf=\"this.status!=null\" >\r\n        <ion-item-divider>\r\n          <ion-label>\r\n            <ion-text color=\"medium\"> Sensor Humedad #1: {{this.status.data.humedad1}}%</ion-text>\r\n          </ion-label>\r\n        </ion-item-divider>\r\n\r\n\r\n        <ion-item>\r\n          \r\n          <ion-avatar slot=\"start\">\r\n            <img src=\"../../assets/img/humidity.jpg\">\r\n          </ion-avatar>\r\n          \r\n          <ion-progress-bar value=\"{{this.status.data.humedad1-0.1}}\" buffer=\"0.05\"></ion-progress-bar>\r\n        </ion-item>\r\n\r\n\r\n        <ion-item-divider>\r\n          <ion-label>\r\n            <ion-text color=\"medium\"> Sensor Humedad #2: {{this.status.data.humedad2}}%</ion-text>\r\n          </ion-label>\r\n        </ion-item-divider>\r\n\r\n        <ion-item>\r\n          <ion-avatar slot=\"start\">\r\n            <img src=\"../../assets/img/humidity.jpg\">\r\n          </ion-avatar>      \r\n          <ion-progress-bar value=\"{{this.status.data.humedad2-0.1}}\" buffer=\"0.05\"></ion-progress-bar>\r\n        </ion-item>\r\n      </div>\r\n\r\n    <ion-fab vertical=\"start\" horizontal=\"end\" edge slot=\"fixed\">\r\n      <ion-fab-button>\r\n        <ion-icon name=\"grid-outline\"></ion-icon>\r\n      </ion-fab-button>\r\n      <ion-fab-list side=\"bottom\">\r\n        <ion-fab-button (click)=\"powerOffSystem()\"><ion-icon name=\"power-outline\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"presentAlert()\" ><ion-icon name=\"wifi-outline\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"presentAlertTemperature()\" ><ion-icon name=\"thermometer-outline\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"presentAlertHumidity()\"><ion-icon name=\"rainy-outline\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"presentAlertTime()\"><ion-icon name=\"alarm\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"presentAlertTipoRiego()\"> <ion-icon name=\"code-download\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"enableAutomatic()\"><ion-icon name=\"logo-android\"></ion-icon></ion-fab-button>\r\n        <ion-fab-button (click)=\"disableAutomatic()\"><ion-icon name=\"person\"></ion-icon></ion-fab-button>\r\n        \r\n      </ion-fab-list>\r\n\r\n    </ion-fab>\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map